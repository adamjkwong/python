from django.urls import path     
from . import views
urlpatterns = [
    path('', views.index),
    path('shows', views.shows),
    path('shows/<int:id>/edit', views.editshow),
    path('shows/<int:id>/delete', views.deleteshow),
    path('shows/new', views.addshow),
    path('shows/add_show', views.add_show),
    path('shows/<int:id>/edit_show', views.edit_show),
    path('shows/<int:id>', views.showsnumber),
]