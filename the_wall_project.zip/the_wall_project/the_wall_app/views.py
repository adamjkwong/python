from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from .models import User, Message, Comment
import bcrypt

def index(request):
    context = {
    	"name": "Noelle",
    	"favorite_color": "turquoise",
    	"pets": ["Bruce", "Fitz", "Georgie"]
    }
    return render(request, "index.html", context)

def register(request):
    if request.method == "POST":
        errors = User.objects.register_validator(request.POST)
        if len(errors) > 0: 
            for key, value in errors.items():
                messages.error(request, value)
            return redirect("/")
        else:
            password = request.POST['password']
            pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
            user = User.objects.create(
                first_name=request.POST['first_name'],
                last_name=request.POST['last_name'],
                email=request.POST['email'], 
                password=pw_hash) 
#    User.objects.create(username=request.POST['username'], password=pw_hash) 
            request.session['user_id'] = user.id
            return redirect("/wall")
    return redirect("/")

def login(request):
    if request.method == "POST":
    # see if the username provided exists in the database
        user = User.objects.filter(email=request.POST['email']) # why are we using filter here instead of get?
        if user: # note that we take advantage of truthiness here: an empty list will return false
            logged_user = user[0] 
        # assuming we only have one user with this username, the user would be first in the list we get back
        # of course, we should have some logic to prevent duplicates of usernames when we create users
        # use bcrypt's check_password_hash method, passing the hash from our database and the password from the form
            if bcrypt.checkpw(request.POST['password'].encode(), logged_user.password.encode()):
            # if we get True after checking the password, we may put the user id in session
                request.session['user_id'] = logged_user.id
            # never render on a post, always redirect!
                return redirect('/wall')
            messages.error(request,"Incorrect login credentials")
        else:
            messages.error(request, "Could not find email address")
    # if we didn't find anything in the database by searching by username or if the passwords don't match, 
    # redirect back to a safe route
    return redirect("/")

def logout(request): 
    request.session.flush()
    return redirect("/")

def post_message(request):
    if not 'user_id' in request.session:
            return redirect("/")
    if request.method == "POST":
        errors = Message.objects.message_validator(request.POST)
        if len(errors) > 0: 
            for value in errors.values():
                messages.error(request, value)
            return redirect("/")
        else:
            new_message = Message.objects.create(
            message=request.POST['message'],
            users=User.objects.get(id=request.session['user_id']))
    return redirect("/wall")

def post_comment(request,m_id):
    if not 'user_id' in request.session:
            return redirect("/")
    if request.method == "POST":
        errors = Comment.objects.comment_validator(request.POST)
        if len(errors) > 0: 
            for value in errors.values():
                messages.error(request, value)
            return redirect("/")
        else:
            new_comment = Comment.objects.create(
            comment=request.POST['comment'],
            users=User.objects.get(id=request.session['user_id']), 
            messages=Message.objects.get(id=m_id)
            )
    return redirect("/wall")

def delete_comment(request,m_id):
    if not 'user_id' in request.session:
            return redirect("/")
    if request.method == "POST":
        delete_comment = Comment.objects.get(id=m_id)
        delete_comment.delete()
    return redirect("/wall")

def delete_message(request,m_id):
    if not 'user_id' in request.session:
            return redirect("/")
    if request.method == "POST":
        delete_message = Message.objects.get(id=m_id)
        delete_message.delete()
    return redirect("/wall")


def wall(request):
    if not 'user_id' in request.session:
            return redirect("/")
    context = {
        "user": User.objects.get(id=request.session['user_id']),
        "message": Message.objects.all(),
        "comment": Comment.objects.all(),
    }
    return render(request, "wall.html", context)