from django.urls import path     
from . import views
urlpatterns = [
    path('', views.index),
    path('register', views.register),
    path('logout', views.logout),
    path('login', views.login),
    path('post_comment/<int:m_id>', views.post_comment),
    path('delete_comment/<int:m_id>', views.delete_comment),
    path('post_message', views.post_message),
    path('delete_message/<int:m_id>', views.delete_message),
    path('wall', views.wall),
]