from django.apps import AppConfig


class UserWTemplatesAppConfig(AppConfig):
    name = 'user_w_templates_app'
