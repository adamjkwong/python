from django.db import models

class User(models.Model):
    first_name = models.CharField(max_length=255, default='0000000', editable=True)
    last_name = models.CharField(max_length=255, default='0000000', editable=True)
    email_address = models.CharField(max_length=255, default='0000000', editable=True)
    age = models.IntegerField(default='0000000', editable=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)