from django.urls import path
from . import views	# the . indicates that the views file can be found in the same directory as this file
                    
urlpatterns = [
    path('', views.index),
    path('login', views.log_and_reg),
    path('logout', views.logout),
    path('register', views.register),
    path('success', views.success),
]