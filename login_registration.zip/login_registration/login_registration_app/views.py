from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
import bcrypt
from .models import User


def index(request):
    return redirect("/login")

def register(request):
    if request.method == "POST":
        errors = User.objects.register_validator(request.POST)
        if len(errors) > 0: 
            for key, value in errors.items():
                messages.error(request, value)
            return redirect("/login")
        else:
            password = request.POST['password']
            pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
            user = User.objects.create(username=request.POST['username'], password=pw_hash) 
            request.session['user_id'] = user.id
            return redirect("/success")
    return redirect("/")

def logout(request): 
    request.session.flush()
    return redirect("/login")

def success(request):
    if not 'user_id' in request.session:
        return redirect("/login")
    context = {
    	"user": User.objects.get(id=request.session['user_id'])
    }
    return render(request, "success.html", context)

def log_and_reg(request):
    return render(request, "log_and_reg.html")