from django.apps import AppConfig


class RestfulTvAppConfig(AppConfig):
    name = 'restful_tv_app'
