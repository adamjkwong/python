from django.shortcuts import render, HttpResponse, redirect
from .models import Show
def index(request):
    context = {
        "all_the_shows": Show.objects.all(),
    }
    return render(request, "index.html", context)

def addshow(request):
    return render(request, "addshow.html")

def add_show(request):
    if request.method == "GET":
        return redirect('/')
    new_show = Show.objects.create(title=request.POST['title'],network=request.POST['network'],release_date=request.POST['release'],description=request.POST['desc'])
    return redirect("/shows/new")

def editshow(request, id):
    context={
        "show": Show.objects.get(id=id)
    }
    return render(request, "editshow.html", context)

def edit_show(request,id):
    show = Show.objects.get(id=id)
    context={
        "show": Show.objects.get(id=id)
    }
    if request.method == "GET":
        return redirect('/')
    if request.method == "POST":
        show.title=request.POST['title']
        show.network=request.POST['network']
        show.release_date=request.POST['release']
        show.description=request.POST['desc']
        show.save()
        return redirect(f"/shows/{show.id}/edit")
    return redirect(f"/shows")

def deleteshow(request, id):
    c = Show.objects.get(id=id)
    #is this supposed to be a request.POST['ID'] Show ID?
    c.delete()
    return redirect("/shows")

def showsnumber(request,id):
    context={
        "show": Show.objects.get(id=id)
    }
    return render(request, "showsnumber.html",context)
